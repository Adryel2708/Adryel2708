let ball;

let leftPaddle;

let rightPaddle;

function setup() {

  createCanvas(600, 400);

  

  // Cria a bola

  ball = new Ball();

  

  // Cria as paletas dos jogadores

  leftPaddle = new Paddle(true);

  rightPaddle = new Paddle(false);

}

function draw() {

  background(0);

  

  // Desenha e atualiza a bola

  ball.update();

  ball.show();

  

  // Desenha e atualiza as paletas

  leftPaddle.show();

  rightPaddle.show();

  

  leftPaddle.update(true);

  rightPaddle.update(false);

  

  // Checa colisão com as paletas

  ball.checkPaddleLeft(leftPaddle);

  ball.checkPaddleRight(rightPaddle);

}

class Ball {

  constructor() {

    this.x = width / 2;

    this.y = height / 2;

    this.r = 12;

    this.xSpeed = 5;

    this.ySpeed = 3;

  }

  update() {

    this.x += this.xSpeed;

    this.y += this.ySpeed;

    

    if (this.y < 0 || this.y > height) {

      this.ySpeed *= -1;

    }

    

    if (this.x < 0 || this.x > width) {

      this.reset();

    }

  }

  show() {

    fill(255);

    ellipse(this.x, this.y, this.r * 2);

  }

  reset() {

    this.x = width / 2;

    this.y = height / 2;

    this.xSpeed *= -1;

  }

  checkPaddleLeft(paddle) {

    if (this.y > paddle.y && this.y < paddle.y + paddle.h && this.x - this.r < paddle.x + paddle.w) {

      if (this.x > paddle.x) {

        this.xSpeed *= -1;

      }

    }

  }

  checkPaddleRight(paddle) {

    if (this.y > paddle.y && this.y < paddle.y + paddle.h && this.x + this.r > paddle.x) {

      if (this.x < paddle.x + paddle.w) {

        this.xSpeed *= -1;

      }

    }

  }

}

class Paddle {

  constructor(isLeft) 

  




    


  






  

    
